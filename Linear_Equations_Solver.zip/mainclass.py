from controller import Controller

controller=Controller()
controller.begin()