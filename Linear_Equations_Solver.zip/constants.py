NO_SOLUTION = "No solution exists!"
INFINITE_SOLUTIONS = "Infinite solutions!"
DIVISION_BY_ZERO = "Division by zero!"
NOT_DIAGONALLY_DOMINANT = "Not diagonally dominant!"

